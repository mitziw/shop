<?php

namespace MGS\Brand\Controller\Adminhtml\Brand;

class ProductGrid extends Product
{

}