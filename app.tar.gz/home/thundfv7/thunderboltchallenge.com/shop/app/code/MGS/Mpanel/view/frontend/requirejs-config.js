var config = {
	"map": {
		"*": {
			"mgs/owlcarousel": "MGS_Mpanel/js/owl.carousel.min",
			"mgs/scrollbar": "MGS_Mpanel/js/jquery.scrollbar.min"
		}
	},
	"paths": {            
		"mgs/owlcarousel": "MGS_Mpanel/js/owl.carousel.min",
		"mgs/scrollbar": "MGS_Mpanel/js/jquery.scrollbar.min"
	},   
    "shim": {"MGS_Mpanel/js/owl.carousel.min": ["jquery"],"MGS_Mpanel/js/jquery.scrollbar.min": ["jquery"]}
};